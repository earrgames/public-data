DISCLAIMER: This is the demo of the first version available at the now defunct Desura, It may be buggy, glitchy, you name it (Also, uncapped fps, beware of your cpu temps XD). This was released around the begginings of August 2014 if I recall correctly, compared to the steam version, this may seem like a prototype.

This demo features a side-story or spinoff related to one of the events of the game, so its contents are not part of the main game. 

It dissapeared from the internet as it no longer represented the quality of the latest versions. So here you have part of the tiny story of Into The Gloom.

Hope you find it "interesting" ;)

--------------- BELOW IS THE AUTHENTIC CONTENT FORM 2014 -------------

Hi! this is the demo version of "Into the gloom", I hope
you like it!

This map is not part of the full game, this is some kind
of prequel! is the history behind the guy with the knife!

Get the full game on Desura!

http://www.desura.com/games/into-the-gloom

Visit the official site at: 
www.intothegloomgame.com

Cheers! and thanks for your support!





Into the Gloom | Copyright Emmanuel Ramos 2014.